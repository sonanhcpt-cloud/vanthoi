#ifndef VOICE_CONFIG_H
#define VOICE_CONFIG_H

// Placeholder config. Replace with your TTS/STT API keys and options.
#define GOOGLE_API_KEY "YOUR_GOOGLE_API_KEY"
#define STARTUP_GREETING "Xin chao, toi la Nguyen Son, rat vui duoc giup ban!"

#endif
